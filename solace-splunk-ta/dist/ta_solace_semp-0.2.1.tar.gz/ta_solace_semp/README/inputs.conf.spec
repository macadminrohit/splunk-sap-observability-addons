[solace_semp://<name>]
account = Broker (from the Configuration tab) to poll.
index = (Default: default)
interval = Polling interval in seconds. Dynatrace polls about every minute; very large VPNs should poll less often. (Default: 60)
max_items = Cap on events per message VPN and object type per poll (0 = unlimited). Truncation is logged. Mainly protects against very large client lists. (Default: 500)
msg_vpn_filter = Comma-separated names or wildcards (e.g. prod-*,shared). Applied client-side. (Default: *)
name_filter = Comma-separated names or wildcards. Use this to cap event volume on busy brokers. (Default: *)
object_types = What to collect. Queues, topic endpoints and clients are the highest-volume; 'System' uses SEMP v1 (XML) for broker-level health. (Default: msgVpn,queue)
trim_config_fields = Drop static configuration attributes (authentication*, authorization*, event*Threshold*, TLS validation settings), duplicated counter.*/rate.* keys and empty values. Telemetry is kept. (Default: 1)
python.required = 3.9, 3.13
* For Python scripts only, selects which Python version to use.
* Set to "3.9" to use the Python 3.9 version.
* Set to "3.13" to use the Python 3.13 version.
* Optional.
* Default: not set
