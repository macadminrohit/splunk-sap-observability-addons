[<name>]
client_id = 
client_secret = 
reporting_url = 
token_url = 
api_url = 
