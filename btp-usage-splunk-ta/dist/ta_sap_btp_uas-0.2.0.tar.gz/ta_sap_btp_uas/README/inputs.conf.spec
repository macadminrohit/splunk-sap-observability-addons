[sap_btp_uas://<name>]
account = Account (from the Configuration tab) to poll.
endpoints = monthlySubaccountsCost only returns data for CPEA consumption-based contracts. (Default: monthlyUsage,monthlySubaccountsCost)
index = (Default: default)
interval = Polling interval in seconds. The API returns monthly figures, so daily (86400) is plenty. (Default: 86400)
months_back = Number of months ending with the current one (1 to 12). 2 re-reads the previous month so late corrections are picked up. (Default: 2)
python.required = 3.9, 3.13
* For Python scripts only, selects which Python version to use.
* Set to "3.9" to use the Python 3.9 version.
* Set to "3.13" to use the Python 3.13 version.
* Optional.
* Default: not set

[sap_calm_catalogue://<name>]
account = Account (Configuration > Cloud ALM accounts) to poll.
index = (Default: default)
interval = Seconds between catalogue refreshes. Daily is plenty; the catalogue rarely changes. (Default: 86400)
python.required = 3.9, 3.13
* For Python scripts only, selects which Python version to use.
* Set to "3.9" to use the Python 3.9 version.
* Set to "3.13" to use the Python 3.13 version.
* Optional.
* Default: not set

[sap_calm_analytics://<name>]
account = Account (Configuration > Cloud ALM accounts) to poll.
format = (Default: table)
index = (Default: default)
interval = Seconds between polls. Rate limits are not documented in the API spec; start at 900 and measure. (Default: 900)
page_size = Rows per request (table format). The maximum the API accepts is not documented. (Default: 500)
queries = JSON array of Cloud ALM Query objects: [{"name":"...","provider":"...","version":"v1","columns":{"dimensions":[...],"metrics":[{"measure":"...","method":"avg"}]},"filters":[{"key":"...","values":["..."]}]}]. Get real provider, dimension and measure names from the sap:calm:provider and sap:calm:dimension events written by the catalogue input.
resolution = Optional. R raw, P one point per period, Mi minutes, H, D, W, M, Y. Blank = API default (D).
table_type = snapshot = aggregated, no timestamps; raw = every row with timestamps (re-reads overlap between polls); last = latest values with timestamps. Table format only. (Default: last)
time_range = Semantic period: L or C (last/current) + number + H, D, W, M or Y. Example L1H = last 1 hour. (Default: L1H)
python.required = 3.9, 3.13
* For Python scripts only, selects which Python version to use.
* Set to "3.9" to use the Python 3.9 version.
* Set to "3.13" to use the Python 3.13 version.
* Optional.
* Default: not set
